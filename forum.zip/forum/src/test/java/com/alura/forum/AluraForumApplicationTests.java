package com.alura.forum;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AluraForumApplicationTests {

	@Test
	void contextLoads() {
	}

}
